package de.robv.android.xposed;

public final class XposedHelpers {
    private XposedHelpers() { }
    public static Class<?> findClassIfExists(String name, ClassLoader cl) { throw new RuntimeException("stub"); }
    public static Object callMethod(Object obj, String methodName, Object... args) { throw new RuntimeException("stub"); }
    public static Object callStaticMethod(Class<?> clazz, String methodName, Object... args) { throw new RuntimeException("stub"); }
    public static Object getObjectField(Object obj, String fieldName) { throw new RuntimeException("stub"); }
    public static float getFloatField(Object obj, String fieldName) { throw new RuntimeException("stub"); }
    public static int getStaticIntField(Class<?> clazz, String fieldName) { throw new RuntimeException("stub"); }
}
